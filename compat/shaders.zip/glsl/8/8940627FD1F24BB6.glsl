//SharedShaders/0x00dc1b7c.ios_vcode uklgonzale Tue Mar 11 16:25:26 2014

precision highp float;



struct VertexInput {
    vec4 _position;
    vec4 _normal;
    vec4 _colorSet0;
};

struct VertexOutput {
    vec4 _varying_position;
    vec4 _varying_colorSet0;
    vec4 _texcoord0;
    vec3 _texcoord1;
    vec2 _texcoord2;
    float _texcoord3;
};

struct FragmentOutput {
    vec4 _color[1];
};

VertexOutput _TMP15;
float _TMP2;
float _TMP6;
float _TMP1;
float _TMP0;
vec3 _TMP4;
vec3 _TMP19;
float _TMP10;
float _TMP9;
float _TMP12;
float _TMP11;
vec4 _TMP8;
vec4 _TMP17[4];
vec4 _C0090[4];
vec3 _v0094;
vec3 _TMP860094[3];
vec3 _r0096;
vec4 _r0101;
vec4 _v0101;
vec4 _r0103;
vec4 _r0109;
vec4 _M0109[4];
vec4 _v0114;
vec4 _b0116;
vec3 _r0125;
float _b0129;
float _a0131;
attribute vec4 NORMAL;
attribute vec4 COLOR;
vec3 _TMP132;
vec3 _TMP133;
vec3 _TMP134;
vec3 _TMP135;
vec3 _TMP136;
vec3 _TMP137;
vec3 _TMP138;
vec3 _TMP139;
vec3 _TMP140;
vec3 _TMP141;
vec3 _TMP142;
vec3 _TMP143;
uniform vec4 _viewProj[4];
uniform vec4 _vs_view[4];
uniform vec4 _world[4];
uniform vec4 _ps2ShineMtx[4];
uniform vec4 _kTint;
uniform vec4 _fog_params;
attribute vec4 cg_Vertex;
varying vec4 cg_FrontColor;
varying vec4 cg_TexCoord1;
varying vec4 cg_TexCoord3;
varying vec4 cg_TexCoord0;
varying vec4 cg_TexCoord2;

 void main()
{

    float _dist;
    float _dd;

    _C0090[0] = _world[0].x*_vs_view[0] + _world[0].y*_vs_view[1] + _world[0].z*_vs_view[2] + _world[0].w*_vs_view[3];
    _C0090[1] = _world[1].x*_vs_view[0] + _world[1].y*_vs_view[1] + _world[1].z*_vs_view[2] + _world[1].w*_vs_view[3];
    _C0090[2] = _world[2].x*_vs_view[0] + _world[2].y*_vs_view[1] + _world[2].z*_vs_view[2] + _world[2].w*_vs_view[3];
    _C0090[3] = _world[3].x*_vs_view[0] + _world[3].y*_vs_view[1] + _world[3].z*_vs_view[2] + _world[3].w*_vs_view[3];
    _TMP17[0] = vec4(float(_C0090[0].x), float(_C0090[0].y), float(_C0090[0].z), float(_C0090[0].w));
    _TMP17[1] = vec4(float(_C0090[1].x), float(_C0090[1].y), float(_C0090[1].z), float(_C0090[1].w));
    _TMP17[2] = vec4(float(_C0090[2].x), float(_C0090[2].y), float(_C0090[2].z), float(_C0090[2].w));
    _TMP17[3] = vec4(float(_C0090[3].x), float(_C0090[3].y), float(_C0090[3].z), float(_C0090[3].w));
    _v0094 = vec3(float((NORMAL.xyz*2.00000000E+000 - 1.00000000E+000).x), float((NORMAL.xyz*2.00000000E+000 - 1.00000000E+000).y), float((NORMAL.xyz*2.00000000E+000 - 1.00000000E+000).z));
    _TMP132.x = _TMP17[0].x;
    _TMP133.y = _TMP17[0].y;
    _TMP134.z = _TMP17[0].z;
    _TMP860094[0] = vec3(float(_TMP132.x), float(_TMP133.y), float(_TMP134.z));
    _TMP135.x = _TMP17[1].x;
    _TMP136.y = _TMP17[1].y;
    _TMP137.z = _TMP17[1].z;
    _TMP860094[1] = vec3(float(_TMP135.x), float(_TMP136.y), float(_TMP137.z));
    _TMP138.x = _TMP17[2].x;
    _TMP139.y = _TMP17[2].y;
    _TMP140.z = _TMP17[2].z;
    _TMP860094[2] = vec3(float(_TMP138.x), float(_TMP139.y), float(_TMP140.z));
    _r0096 = _v0094.x*_TMP860094[0];
    _r0096 = _r0096 + _v0094.y*_TMP860094[1];
    _r0096 = _r0096 + _v0094.z*_TMP860094[2];
    _TMP19 = vec3(float(_r0096.x), float(_r0096.y), float(_r0096.z));
    _v0101 = vec4(cg_Vertex.x, cg_Vertex.y, cg_Vertex.z, 1.00000000E+000);
    _r0101 = _v0101.x*_world[0];
    _r0101 = _r0101 + _v0101.y*_world[1];
    _r0101 = _r0101 + _v0101.z*_world[2];
    _r0101 = _r0101 + _v0101.w*_world[3];
    _r0103 = _r0101.x*_viewProj[0];
    _r0103 = _r0103 + _r0101.y*_viewProj[1];
    _r0103 = _r0103 + _r0101.z*_viewProj[2];
    _r0103 = _r0103 + _r0101.w*_viewProj[3];
    _M0109[0] = vec4(float(_TMP17[0].x), float(_TMP17[0].y), float(_TMP17[0].z), float(_TMP17[0].w));
    _M0109[1] = vec4(float(_TMP17[1].x), float(_TMP17[1].y), float(_TMP17[1].z), float(_TMP17[1].w));
    _M0109[2] = vec4(float(_TMP17[2].x), float(_TMP17[2].y), float(_TMP17[2].z), float(_TMP17[2].w));
    _M0109[3] = vec4(float(_TMP17[3].x), float(_TMP17[3].y), float(_TMP17[3].z), float(_TMP17[3].w));
    _r0109 = cg_Vertex.x*_M0109[0];
    _r0109 = _r0109 + cg_Vertex.y*_M0109[1];
    _r0109 = _r0109 + cg_Vertex.z*_M0109[2];
    _r0109 = _r0109 + cg_Vertex.w*_M0109[3];
    _TMP15._texcoord0.xyzw = vec4(float(_TMP19.x), float(_TMP19.y), float(_TMP19.z), 1.00000000E+000);
    _v0114 = vec4(float(float(((COLOR*_kTint)*2.00000000E+000).x)), float(float(((COLOR*_kTint)*2.00000000E+000).y)), float(float(((COLOR*_kTint)*2.00000000E+000).z)), float(float(((COLOR*_kTint)*2.00000000E+000).w)));
    _b0116 = vec4(float(_v0114.x), float(_v0114.y), float(_v0114.z), float(_v0114.w));
    _TMP8 = (_b0116);
    _TMP15._varying_colorSet0 = vec4(float(_TMP8.x), float(_TMP8.y), float(_TMP8.z), float(_TMP8.w));
    _TMP11 = dot(vec3(float(_TMP19.x), float(_TMP19.y), float(_TMP19.z)), vec3(float(_TMP19.x), float(_TMP19.y), float(_TMP19.z)));
    _TMP9 = float(_TMP11);
    _TMP12 = inversesqrt(float(_TMP9));
    _TMP10 = float(_TMP12);
    _TMP4 = _TMP10*_TMP19;
    _TMP141.x = _ps2ShineMtx[0].x;
    _TMP141.y = _ps2ShineMtx[0].y;
    _TMP141.z = _ps2ShineMtx[0].z;
    _r0125 = _TMP4.x*_TMP141;
    _TMP142.x = _ps2ShineMtx[1].x;
    _TMP142.y = _ps2ShineMtx[1].y;
    _TMP142.z = _ps2ShineMtx[1].z;
    _r0125 = _r0125 + _TMP4.y*_TMP142;
    _TMP143.x = _ps2ShineMtx[2].x;
    _TMP143.y = _ps2ShineMtx[2].y;
    _TMP143.z = _ps2ShineMtx[2].z;
    _r0125 = _r0125 + _TMP4.z*_TMP143;
    _TMP15._texcoord2.xy = vec2(float(_r0125.x), float(_r0125.y));
    _TMP0 = length(_r0109.xyz);
    _b0129 = _TMP0 - float(_fog_params.x);
    _TMP1 = max(0.00000000E+000, _b0129);
    _dist = float(_TMP1);
    _a0131 = _dist/_fog_params.z;
    _TMP6 = min(float(_a0131), 1.00000000E+000);
    _TMP2 = float(_TMP6);
    _dd = float((1.00000000E+000 - float(_TMP2)));
    _TMP15._texcoord3 = float(_dd);
    cg_TexCoord2.xy = _TMP15._texcoord2;
    cg_TexCoord0 = _TMP15._texcoord0;
    cg_TexCoord3.x = _TMP15._texcoord3;
    cg_TexCoord1.xyz = _r0109.xyz;
    gl_Position = _r0103;
    cg_FrontColor = vec4(float(_TMP15._varying_colorSet0.x), float(_TMP15._varying_colorSet0.y), float(_TMP15._varying_colorSet0.z), float(_TMP15._varying_colorSet0.w));
    return;
} 
